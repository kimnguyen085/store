// JavaScript Document
function upload() {
	$('#progress').animate( {width: "100%" }, "swing", function() {
		$('#msg_upload').text("Upload complete");
		$('#msg_import').text("Import complete");
		$(this).unbind("click");
	});
}