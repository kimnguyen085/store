package calculatepi;

import static org.junit.Assert.*;

import java.util.concurrent.ExecutionException;

import org.junit.Assert;
import org.junit.Test;

public class ExerciseTest {

    @Test
    public void test() throws ExecutionException, InterruptedException {
        // with epsilon 10E-8, expected value 3.14159263 -3.14159265
//        long n =Exercise.getLoopEndValueFromEpsilon(0.00000001);
//        System.out.println(n);
//        Exercise.calculatePiValue(n);
//        double pi = Exercise.piValue;
//        System.out.println(pi);
        
        Assert.assertEquals(1, 2);
    }

}
