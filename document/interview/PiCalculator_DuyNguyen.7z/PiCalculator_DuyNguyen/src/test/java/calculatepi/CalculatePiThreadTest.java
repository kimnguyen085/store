package calculatepi;

import static org.junit.Assert.assertEquals;

import java.text.DecimalFormat;

import org.junit.Test;


public class CalculatePiThreadTest {


    @Test
    public void testCall() throws Exception {
        CalculatePiThread test1 = new CalculatePiThread(0, 1000);
        System.out.println(test1.call());
    }

}
