package calculatepi;

import static org.junit.Assert.*;

import java.util.concurrent.ExecutionException;

import org.junit.Assert;
import org.junit.Test;


public class ExerciseTestWithDirectInputN {

    @Test
    public void testGetLoopEndValueFromEpsilon() throws InterruptedException, ExecutionException {
        Exercise.calculatePiValue(1000000000);
//        Assert.assertEquals("","asdasddas");
    }

}
