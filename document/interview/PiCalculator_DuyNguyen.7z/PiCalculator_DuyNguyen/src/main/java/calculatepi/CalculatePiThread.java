package calculatepi;

import java.util.concurrent.Callable;

public class CalculatePiThread implements Callable<Double> {

    private long loopStart;
    private long loopEnd;
    private double result;

    public CalculatePiThread(long loopStart, long loopEnd) {
        super();
        this.loopStart = loopStart;
        this.loopEnd = loopEnd;
    }

    public Double call() {
        try {
            int j;
            if (loopStart % 2 == 0) {
                j = 1;
            } else {
                j = -1;
            }
            for (long i = loopStart; i <= loopEnd; i++) {
                result += 4.0 * j / (2 * i + 1);
                j *= (-1);
            }
            return result;

        } catch (Exception e) {
            return 0.0;
        }

    }

}
