package calculatepi;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * @author nguyenduy
 */
public class Exercise {

    static double piValue;
    static int numberOfThread = 10;

    public static void main(String[] args) throws InterruptedException, ExecutionException {
        double epsilon = 0;
        long loopEndValue;
        Scanner scanIn = new Scanner(System.in);
        do {
            System.out.println("Please enter Epsilon number between 0.1 and 10E-15");
            while (!scanIn.hasNextDouble()) {
                System.out.println("The input is not a number, Please re-enter Epsilon:");
                scanIn.next();
            }
            epsilon = scanIn.nextDouble();
        } while ((epsilon < 10E-15) || (epsilon > 0.1));

        System.out.println(epsilon);

        loopEndValue = getLoopEndValueFromEpsilon(epsilon);

        System.out.println("The Epsilon value is: " + epsilon);
        DecimalFormat formatter = new DecimalFormat("#,###");
        System.out.println("Loop End value get from Epsilon is:    " + formatter.format(loopEndValue));

        calculatePiValue(loopEndValue);
        scanIn.close();
    }

    public static long getLoopEndValueFromEpsilon(double epsilon) {
        double loopEndValueInDouble;
        /*
         * Epsilon is a very small number that if we plus/sub into the result, it still doesnt effect to the final
         * result .With the input epsilon, the loop will end with value n match the condition:
         * 4 / (2*n +1) < epsilon => ((4 / epsilon) - 1) / 2 <n
         */
        loopEndValueInDouble = ((4 / epsilon) - 1) / 2;

        // get the Long value part as Loop end value
        return (long) loopEndValueInDouble;

    }

    public static void calculatePiValue(long loopEndValue) throws InterruptedException, ExecutionException {
        ExecutorService executor = Executors.newFixedThreadPool(numberOfThread);
        List<CalculatePiThread> calculateList = new ArrayList<CalculatePiThread>();

        if (loopEndValue < 10000) {
            Future<Double> future = executor.submit(new CalculatePiThread(0, loopEndValue));
            piValue = future.get();
            System.out.println("Value of Pi with the input Epsilon is: " + piValue);
        } else {
            /*
             * Create number of instances = number of thread with parameter difference by
             * a step size = (loopEndValue / numberOfThread)
             */
            for (int i = 1; i <= numberOfThread; i++) {
                if (i == 1) {
                    calculateList.add(new CalculatePiThread(0, i * loopEndValue / numberOfThread));
                } else {
                    calculateList.add(new CalculatePiThread((i - 1) * loopEndValue / numberOfThread + 1, i
                        * loopEndValue
                        / numberOfThread));
                }
            }

            try {
                // set time limit for executor is 2 minutes, if overtime, it will be canceled
                List<Future<Double>> results = executor.invokeAll(calculateList, 2, TimeUnit.MINUTES);
                for (Future<Double> result : results) {
                    piValue += result.get();
                }
                System.out.println("Value of Pi with the input Epsilon is: " + piValue);

            } catch (Exception e) {
                System.out.println("Progress is interupted due to Timeout");
            } finally
            {
                executor.shutdown();
                System.exit(0);
            }
        }
    }
}
