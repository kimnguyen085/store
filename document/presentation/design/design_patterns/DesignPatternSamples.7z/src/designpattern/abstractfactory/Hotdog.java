package designpattern.abstractfactory;

public interface Hotdog  extends Item {

}
