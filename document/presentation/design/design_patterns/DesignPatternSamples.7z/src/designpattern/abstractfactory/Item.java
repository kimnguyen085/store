package designpattern.abstractfactory;

public interface Item {

}
