package designpattern.abstractfactory;

public class NewYorkFoodFactory implements FoodFactory {

    public Pizza createPizza() {
        return new NewYorkPizza();
    }

    public Hotdog createHotdog() {
        return new NewYorkHotdog();
    }
}

class NewYorkPizza implements Pizza {

    public NewYorkPizza() {
        System.out.println("A NewYorkPizza created!");
    }
}

class NewYorkHotdog implements Hotdog {

    public NewYorkHotdog() {
        System.out.println("A NewYorkHotdog created!");
    }
}

