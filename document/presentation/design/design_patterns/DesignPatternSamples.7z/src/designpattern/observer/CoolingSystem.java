package designpattern.observer;

import java.util.Observable;
import java.util.Observer;

public class CoolingSystem implements Observer {

    public void update(Observable o, Object arg) {
        Door.DoorState doorState = (Door.DoorState) arg;
        if (doorState == Door.DoorState.OPEN) {
            standby();
        } else {
            resume();
        }
    }

    private void standby() {
        System.out.println("The cooling system is standby!");
    }

    private void resume() {
        System.out.println("The cooling system is resumed!");
    }

}
