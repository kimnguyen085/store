package designpattern.observer;

public class Main {

    public static void main(String[] args) {
        class Refrigerator {

            Door door = new Door();
            private CoolingSystem cooler = new CoolingSystem();
            private Light light = new Light();

            public Refrigerator() {
                door.addObserver(cooler);
                door.addObserver(light);
            }

            public Door getDoor() {
                return door;
            }
        }

        Refrigerator r = new Refrigerator();
        r.getDoor().open();
        r.getDoor().close();
    }
}

