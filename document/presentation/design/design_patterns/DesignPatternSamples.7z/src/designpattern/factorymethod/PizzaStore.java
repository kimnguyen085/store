package designpattern.factorymethod;

public abstract class PizzaStore {
    public Pizza orderPizza() {
        Pizza pizza = createPizza();
        bake(pizza);
        box(pizza);
        return pizza;
    }

    // factory method
    protected abstract Pizza createPizza();

    // We may have a default implementation of the factory method like this
    // protected Pizza createPizza() {
    //    return new MyPizza();
    // }


    private void bake(Pizza pizza) {
        // Bake the pizza
        System.out.println("The pizza has been baked!");
    }

    private void box(Pizza pizza) {
        // Box the pizza
        System.out.println("The pizza has been boxed!");
    }
}

