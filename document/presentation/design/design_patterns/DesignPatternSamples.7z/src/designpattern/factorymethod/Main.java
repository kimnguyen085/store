package designpattern.factorymethod;

public class Main {
    public static void main(String[] args) {
        PizzaStore s1 = new ChicagoPizzaStore();
        s1.orderPizza();

        PizzaStore s2 = new NewYorkPizzaStore();
        s2.orderPizza();
    }
}
