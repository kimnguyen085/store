package designpattern.factorymethod;

public class NewYorkPizzaStore extends PizzaStore {

    protected Pizza createPizza() {
        return new NewYorkPizza();
    }
}

class NewYorkPizza implements Pizza {

    public NewYorkPizza() {
        // Create a NewYork specific pizza
        System.out.println("A NewYorkPizza created!");
    }
}

