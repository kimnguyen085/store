package designpattern.command;

import java.util.Random;
import javax.swing.JTextArea;

public class InsertCommand implements Command {

    transient JTextArea textArea;
    Data data;

    public InsertCommand(JTextArea textArea) {
        this.textArea = textArea;
    }

    public Data updateData() {
        data = new Data(textArea.getCaretPosition(), createRandomString());
        return data;
    }

    public void setData(Data data) {
        this.data = data;
    }

    public Data getData() {
        return data;
    }

    public void execute() {

        textArea.insert(data.getText(), data.getPosition());
        System.out.println("\'" + data.getText() + "\' inserted at " + data.getPosition() + "!");
    }

    public void unExecute() {
        if (data == null) {
            return;
        }
        textArea.replaceRange("", data.getPosition(), data.getPosition() + data.getText().length());
        System.out.println("\' " + data.getText() + "\' deleted at " + data.getPosition() + "!");
    }

    /**
     * Create a random string
     */
    private String createRandomString() {
        String[] pool = {" The ", " <code>String</code>", " class",
            " represents", " character", " strings"};
        int random = new Random().nextInt(pool.length);

        return pool[random];
    }

    @Override
    public InsertCommand clone() throws CloneNotSupportedException {
        return (InsertCommand) super.clone();
    }
}
