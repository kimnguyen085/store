package designpattern.command;

public interface Command extends Cloneable {
    public void setData(Data d);
    public Data getData();
    public Data updateData();
    public void execute();
    public void unExecute();
    public Command clone() throws CloneNotSupportedException;

}
