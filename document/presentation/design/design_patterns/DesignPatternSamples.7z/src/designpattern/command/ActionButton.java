package designpattern.command;

import designpattern.command.singleton.UnRedo;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ActionButton extends JButton {

    public ActionButton(final Command c) {
        addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                Data d = c.updateData();
                if (d == null) {
                    return;
                }
                c.execute();
                try {
                    UnRedo.getInstance().addCommand(c.clone());
                } catch (CloneNotSupportedException ex) {
                    Logger.getLogger(ActionButton.class.getName()).log(Level.SEVERE, null, ex);
                    System.out.println("Problem happend while storing command to stack!");
                }
            }
        });
    }
}
