package more.factorymethod;

enum ProductId {

    MINE, YOURS
}

public class Creator {

    Product create(ProductId id) {
        if (id == ProductId.MINE) {
            return new MyProduct();
        }
        if (id == ProductId.YOURS) {
            return new YourProduct();
        }
        // ...
        return null;
    }
}

interface Product {
}

class MyProduct implements Product {
}

class YourProduct implements Product {
}
